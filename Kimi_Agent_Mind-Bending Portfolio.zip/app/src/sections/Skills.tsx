import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  Code2,
  Database,
  Layout,
  Server,
  Smartphone,
  Cloud,
  Terminal,
  GitBranch,
  Cpu,
  Layers,
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const skillCategories = [
  {
    title: 'Frontend Development',
    icon: Layout,
    skills: [
      { name: 'React / Next.js', level: 90 },
      { name: 'TypeScript', level: 85 },
      { name: 'Tailwind CSS', level: 95 },
      { name: 'HTML/CSS', level: 95 },
    ],
    color: 'from-cyan-400 to-blue-500',
  },
  {
    title: 'Backend Development',
    icon: Server,
    skills: [
      { name: 'Node.js', level: 85 },
      { name: 'Python', level: 80 },
      { name: 'Express.js', level: 82 },
      { name: 'REST APIs', level: 88 },
    ],
    color: 'from-purple-400 to-pink-500',
  },
  {
    title: 'Database & Cloud',
    icon: Database,
    skills: [
      { name: 'MongoDB', level: 80 },
      { name: 'PostgreSQL', level: 75 },
      { name: 'AWS', level: 70 },
      { name: 'Docker', level: 72 },
    ],
    color: 'from-orange-400 to-red-500',
  },
  {
    title: 'Mobile Development',
    icon: Smartphone,
    skills: [
      { name: 'React Native', level: 75 },
      { name: 'Flutter', level: 65 },
      { name: 'iOS/Android', level: 70 },
    ],
    color: 'from-green-400 to-teal-500',
  },
];

const techStack = [
  { name: 'React', icon: Code2 },
  { name: 'Node.js', icon: Server },
  { name: 'Python', icon: Terminal },
  { name: 'MongoDB', icon: Database },
  { name: 'Git', icon: GitBranch },
  { name: 'AWS', icon: Cloud },
  { name: 'Docker', icon: Layers },
  { name: 'System Design', icon: Cpu },
];

const Skills = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const techRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Skill cards animation
      gsap.fromTo(
        cardsRef.current?.children || [],
        {
          opacity: 0,
          y: 60,
          rotateX: -15,
        },
        {
          opacity: 1,
          y: 0,
          rotateX: 0,
          duration: 0.8,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: cardsRef.current,
            start: 'top 75%',
          },
        }
      );

      // Progress bars animation
      const progressBars = sectionRef.current?.querySelectorAll('.skill-progress');
      progressBars?.forEach((bar) => {
        const width = bar.getAttribute('data-width');
        gsap.fromTo(
          bar,
          { width: '0%' },
          {
            width: `${width}%`,
            duration: 1.5,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: bar,
              start: 'top 85%',
            },
          }
        );
      });

      // Tech stack animation
      gsap.fromTo(
        techRef.current?.children || [],
        {
          opacity: 0,
          scale: 0.5,
        },
        {
          opacity: 1,
          scale: 1,
          duration: 0.5,
          stagger: {
            each: 0.08,
            from: 'random',
          },
          ease: 'back.out(1.7)',
          scrollTrigger: {
            trigger: techRef.current,
            start: 'top 85%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="skills"
      ref={sectionRef}
      className="relative py-24 md:py-32 section-reveal"
    >
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 mb-4 text-sm font-mono text-cyan-400 glass rounded-full">
            My Expertise
          </span>
          <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk mb-4">
            <span className="text-white">Skills & </span>
            <span className="gradient-text">Technologies</span>
          </h2>
          <p className="max-w-2xl mx-auto text-white/60">
            A comprehensive toolkit of technologies and skills I've mastered to bring 
            ideas to life and solve complex problems.
          </p>
        </div>

        {/* Skill Categories */}
        <div
          ref={cardsRef}
          className="grid md:grid-cols-2 gap-6 mb-20"
        >
          {skillCategories.map((category) => (
            <div
              key={category.title}
              className="group glass rounded-2xl p-6 hover-lift gradient-border card-3d"
            >
              <div className="flex items-center gap-4 mb-6">
                <div
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${category.color} flex items-center justify-center`}
                >
                  <category.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white">
                  {category.title}
                </h3>
              </div>

              <div className="space-y-4">
                {category.skills.map((skill) => (
                  <div key={skill.name}>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm text-white/80">{skill.name}</span>
                      <span className="text-sm text-white/50">{skill.level}%</span>
                    </div>
                    <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                      <div
                        className={`skill-progress h-full rounded-full bg-gradient-to-r ${category.color}`}
                        data-width={skill.level}
                        style={{ width: '0%' }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Tech Stack */}
        <div className="text-center mb-8">
          <h3 className="text-2xl font-semibold text-white mb-2">
            Tech Stack
          </h3>
          <p className="text-white/50">Tools and technologies I work with daily</p>
        </div>

        <div
          ref={techRef}
          className="flex flex-wrap justify-center gap-4"
        >
          {techStack.map((tech) => (
            <div
              key={tech.name}
              className="group flex items-center gap-3 px-5 py-3 glass rounded-full hover:bg-white/10 transition-all duration-300 hover:scale-105 cursor-default"
            >
              <tech.icon className="w-5 h-5 text-cyan-400 group-hover:text-purple-400 transition-colors" />
              <span className="text-white/80 group-hover:text-white transition-colors">
                {tech.name}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
