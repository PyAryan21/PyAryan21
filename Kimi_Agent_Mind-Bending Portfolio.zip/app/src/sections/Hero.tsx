import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ArrowDown, Github, Linkedin, Twitter, Mail } from 'lucide-react';

const Hero = () => {
  const heroRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const socialsRef = useRef<HTMLDivElement>(null);
  const decorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation with 3D effect
      gsap.fromTo(
        titleRef.current,
        {
          opacity: 0,
          y: 100,
          rotateX: -45,
        },
        {
          opacity: 1,
          y: 0,
          rotateX: 0,
          duration: 1.2,
          ease: 'power4.out',
          delay: 0.3,
        }
      );

      // Subtitle animation
      gsap.fromTo(
        subtitleRef.current,
        {
          opacity: 0,
          y: 50,
        },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          ease: 'power3.out',
          delay: 0.6,
        }
      );

      // CTA buttons animation
      gsap.fromTo(
        ctaRef.current?.children || [],
        {
          opacity: 0,
          y: 30,
          scale: 0.9,
        },
        {
          opacity: 1,
          y: 0,
          scale: 1,
          duration: 0.8,
          stagger: 0.15,
          ease: 'back.out(1.7)',
          delay: 0.9,
        }
      );

      // Social links animation
      gsap.fromTo(
        socialsRef.current?.children || [],
        {
          opacity: 0,
          x: -30,
        },
        {
          opacity: 1,
          x: 0,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power2.out',
          delay: 1.2,
        }
      );

      // Decorative elements animation
      gsap.fromTo(
        decorRef.current?.children || [],
        {
          opacity: 0,
          scale: 0,
        },
        {
          opacity: 1,
          scale: 1,
          duration: 1.5,
          stagger: 0.2,
          ease: 'elastic.out(1, 0.5)',
          delay: 0.5,
        }
      );

      // Continuous floating animation for decorative elements
      gsap.to('.float-element', {
        y: -20,
        duration: 3,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1,
        stagger: {
          each: 0.5,
          from: 'random',
        },
      });

      // Rotating gradient orb
      gsap.to('.gradient-orb', {
        rotation: 360,
        duration: 20,
        ease: 'none',
        repeat: -1,
      });
    }, heroRef);

    return () => ctx.revert();
  }, []);

  const handleScrollDown = () => {
    const aboutSection = document.getElementById('about');
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20"
    >
      {/* Decorative Elements */}
      <div ref={decorRef} className="absolute inset-0 pointer-events-none">
        {/* Floating geometric shapes */}
        <div className="float-element absolute top-20 left-[10%] w-20 h-20 border border-cyan-500/30 rotate-45" />
        <div className="float-element absolute top-40 right-[15%] w-16 h-16 border border-purple-500/30 rounded-full" />
        <div className="float-element absolute bottom-32 left-[20%] w-12 h-12 bg-gradient-to-br from-cyan-500/20 to-purple-500/20 rotate-12" />
        <div className="float-element absolute bottom-20 right-[25%] w-24 h-24 border border-pink-500/20 rotate-45" />
        
        {/* Gradient orbs */}
        <div className="gradient-orb absolute top-1/4 left-1/4 w-64 h-64 bg-gradient-conic from-cyan-500/20 via-purple-500/20 to-pink-500/20 rounded-full blur-3xl opacity-50" />
        <div className="gradient-orb absolute bottom-1/4 right-1/4 w-48 h-48 bg-gradient-conic from-purple-500/20 via-pink-500/20 to-cyan-500/20 rounded-full blur-3xl opacity-50" />
        
        {/* Code-like decorative text */}
        <div className="absolute top-1/3 right-[5%] text-xs font-mono text-cyan-500/20 leading-relaxed hidden lg:block">
          {'<developer>'}<br />
          &nbsp;&nbsp;{'name: "Aryan"'}<br />
          &nbsp;&nbsp;{'role: "Engineer"'}<br />
          &nbsp;&nbsp;{'passion: "Innovation"'}<br />
          {'</developer>'}
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 mb-8 glass rounded-full">
          <span className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
          <span className="text-sm text-white/80">Available for opportunities</span>
        </div>

        {/* Main Title */}
        <h1
          ref={titleRef}
          className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold font-space-grotesk mb-6 perspective-1000"
        >
          <span className="block text-white mb-2">Hi, I'm</span>
          <span className="block gradient-text text-glow">Aryan Rakhecha</span>
        </h1>

        {/* Subtitle */}
        <p
          ref={subtitleRef}
          className="text-xl sm:text-2xl md:text-3xl text-white/70 mb-4 font-light"
        >
          Engineering Student & Creative Developer
        </p>

        {/* Description */}
        <p className="max-w-2xl mx-auto text-base sm:text-lg text-white/50 mb-10 leading-relaxed">
          Passionate about building innovative solutions and creating mind-bending digital experiences. 
          Transforming ideas into reality through code and creativity.
        </p>

        {/* CTA Buttons */}
        <div ref={ctaRef} className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
          <a
            href="#projects"
            onClick={(e) => {
              e.preventDefault();
              document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="group relative px-8 py-4 text-lg font-medium text-background bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 rounded-full overflow-hidden transition-all duration-300 hover:shadow-2xl hover:shadow-cyan-500/30 hover:scale-105"
          >
            <span className="relative z-10">View My Work</span>
            <div className="absolute inset-0 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          </a>
          <a
            href="#contact"
            onClick={(e) => {
              e.preventDefault();
              document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="px-8 py-4 text-lg font-medium text-white border border-white/20 rounded-full hover:bg-white/5 hover:border-white/40 transition-all duration-300"
          >
            Get In Touch
          </a>
        </div>

        {/* Social Links */}
        <div ref={socialsRef} className="flex items-center justify-center gap-4">
          {[
            { icon: Github, href: 'https://github.com', label: 'GitHub' },
            { icon: Linkedin, href: 'https://linkedin.com', label: 'LinkedIn' },
            { icon: Twitter, href: 'https://twitter.com', label: 'Twitter' },
            { icon: Mail, href: 'mailto:aryan@example.com', label: 'Email' },
          ].map((social) => (
            <a
              key={social.label}
              href={social.href}
              target="_blank"
              rel="noopener noreferrer"
              className="group p-3 glass rounded-full hover:bg-white/10 transition-all duration-300 hover:scale-110"
              aria-label={social.label}
            >
              <social.icon className="w-5 h-5 text-white/60 group-hover:text-cyan-400 transition-colors" />
            </a>
          ))}
        </div>
      </div>

      {/* Scroll Indicator */}
      <button
        onClick={handleScrollDown}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/40 hover:text-white/80 transition-colors group"
      >
        <span className="text-xs tracking-widest uppercase">Scroll</span>
        <ArrowDown className="w-5 h-5 animate-bounce" />
      </button>
    </section>
  );
};

export default Hero;
