import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ExternalLink, Github, ArrowUpRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const projects = [
  {
    title: 'AI-Powered Analytics Dashboard',
    description:
      'A comprehensive analytics platform with real-time data visualization, machine learning predictions, and interactive charts for business intelligence.',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=500&fit=crop',
    tags: ['React', 'TypeScript', 'Python', 'TensorFlow', 'D3.js'],
    github: 'https://github.com',
    demo: 'https://demo.com',
    featured: true,
  },
  {
    title: 'E-Commerce Platform',
    description:
      'Full-stack e-commerce solution with payment integration, inventory management, and real-time order tracking.',
    image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&h=500&fit=crop',
    tags: ['Next.js', 'Node.js', 'MongoDB', 'Stripe', 'Redis'],
    github: 'https://github.com',
    demo: 'https://demo.com',
    featured: true,
  },
  {
    title: 'Social Media App',
    description:
      'Mobile-first social platform with real-time messaging, story features, and AI-powered content recommendations.',
    image: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800&h=500&fit=crop',
    tags: ['React Native', 'Firebase', 'GraphQL', 'WebSocket'],
    github: 'https://github.com',
    demo: 'https://demo.com',
    featured: false,
  },
  {
    title: 'Cloud Infrastructure Manager',
    description:
      'DevOps tool for managing cloud resources, automating deployments, and monitoring system health across multiple providers.',
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&h=500&fit=crop',
    tags: ['Go', 'Docker', 'Kubernetes', 'AWS', 'Terraform'],
    github: 'https://github.com',
    demo: 'https://demo.com',
    featured: false,
  },
  {
    title: 'Blockchain Wallet',
    description:
      'Secure cryptocurrency wallet with multi-chain support, DeFi integrations, and NFT marketplace features.',
    image: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=800&h=500&fit=crop',
    tags: ['Solidity', 'Web3.js', 'React', 'Ethereum', 'IPFS'],
    github: 'https://github.com',
    demo: 'https://demo.com',
    featured: false,
  },
  {
    title: 'IoT Smart Home System',
    description:
      'Home automation platform connecting various IoT devices with voice control and energy optimization.',
    image: 'https://images.unsplash.com/photo-1558002038-1055907df827?w=800&h=500&fit=crop',
    tags: ['Python', 'Raspberry Pi', 'MQTT', 'React', 'TensorFlow'],
    github: 'https://github.com',
    demo: 'https://demo.com',
    featured: false,
  },
];

const Projects = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const projectsRef = useRef<HTMLDivElement>(null);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Projects reveal animation
      gsap.fromTo(
        projectsRef.current?.children || [],
        {
          opacity: 0,
          y: 80,
        },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: projectsRef.current,
            start: 'top 75%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="projects"
      ref={sectionRef}
      className="relative py-24 md:py-32 section-reveal"
    >
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16">
          <div>
            <span className="inline-block px-4 py-2 mb-4 text-sm font-mono text-cyan-400 glass rounded-full">
              Portfolio
            </span>
            <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk">
              <span className="text-white">Featured </span>
              <span className="gradient-text">Projects</span>
            </h2>
          </div>
          <p className="max-w-md text-white/60">
            A selection of my recent work showcasing my skills in design, 
            development, and problem-solving.
          </p>
        </div>

        {/* Projects Grid */}
        <div
          ref={projectsRef}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {projects.map((project, index) => (
            <div
              key={project.title}
              className={`group relative rounded-2xl overflow-hidden gradient-border hover-lift ${
                project.featured ? 'md:col-span-2 lg:col-span-1' : ''
              }`}
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
            >
              {/* Background Image */}
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
                
                {/* Featured Badge */}
                {project.featured && (
                  <div className="absolute top-4 left-4 px-3 py-1 text-xs font-medium text-background bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full">
                    Featured
                  </div>
                )}

                {/* Content */}
                <div className="absolute inset-0 p-6 flex flex-col justify-end">
                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-3 opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
                    {project.tags.slice(0, 3).map((tag) => (
                      <span
                        key={tag}
                        className="px-2 py-1 text-xs text-white/80 glass rounded"
                      >
                        {tag}
                      </span>
                    ))}
                    {project.tags.length > 3 && (
                      <span className="px-2 py-1 text-xs text-white/60 glass rounded">
                        +{project.tags.length - 3}
                      </span>
                    )}
                  </div>

                  {/* Title */}
                  <h3 className="text-xl font-semibold text-white mb-2 group-hover:gradient-text transition-all duration-300">
                    {project.title}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-white/60 mb-4 line-clamp-2 opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300 delay-75">
                    {project.description}
                  </p>

                  {/* Links */}
                  <div className="flex gap-3 opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300 delay-100">
                    <a
                      href={project.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2 text-sm text-white/80 glass rounded-full hover:bg-white/10 transition-colors"
                    >
                      <Github className="w-4 h-4" />
                      Code
                    </a>
                    <a
                      href={project.demo}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2 text-sm text-background bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full hover:shadow-lg hover:shadow-cyan-500/25 transition-all"
                    >
                      <ExternalLink className="w-4 h-4" />
                      Live Demo
                    </a>
                  </div>
                </div>

                {/* Hover Arrow */}
                <div
                  className={`absolute top-4 right-4 w-10 h-10 glass rounded-full flex items-center justify-center transition-all duration-300 ${
                    hoveredIndex === index
                      ? 'opacity-100 scale-100'
                      : 'opacity-0 scale-75'
                  }`}
                >
                  <ArrowUpRight className="w-5 h-5 text-cyan-400" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View More */}
        <div className="text-center mt-12">
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 text-white border border-white/20 rounded-full hover:bg-white/5 hover:border-white/40 transition-all duration-300 group"
          >
            <Github className="w-5 h-5" />
            View More on GitHub
            <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Projects;
