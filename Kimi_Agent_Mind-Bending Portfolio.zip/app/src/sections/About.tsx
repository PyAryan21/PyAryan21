import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Code2, Lightbulb, Rocket, Users } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const stats = [
  { value: '3+', label: 'Years Experience', icon: Code2 },
  { value: '20+', label: 'Projects Completed', icon: Rocket },
  { value: '15+', label: 'Technologies', icon: Lightbulb },
  { value: '50+', label: 'Collaborations', icon: Users },
];

const About = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Content reveal animation
      gsap.fromTo(
        contentRef.current?.children || [],
        {
          opacity: 0,
          x: -50,
        },
        {
          opacity: 1,
          x: 0,
          duration: 0.8,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
          },
        }
      );

      // Image reveal animation
      gsap.fromTo(
        imageRef.current,
        {
          opacity: 0,
          x: 50,
          scale: 0.9,
        },
        {
          opacity: 1,
          x: 0,
          scale: 1,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
          },
        }
      );

      // Stats counter animation
      const statElements = statsRef.current?.querySelectorAll('.stat-value');
      statElements?.forEach((el) => {
        const target = el.getAttribute('data-value');
        if (target) {
          gsap.fromTo(
            el,
            { innerText: '0' },
            {
              innerText: target,
              duration: 2,
              ease: 'power2.out',
              snap: { innerText: 1 },
              scrollTrigger: {
                trigger: statsRef.current,
                start: 'top 80%',
              },
            }
          );
        }
      });

      // Stats cards stagger animation
      gsap.fromTo(
        statsRef.current?.children || [],
        {
          opacity: 0,
          y: 30,
        },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: statsRef.current,
            start: 'top 85%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-24 md:py-32 section-reveal"
    >
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="flex items-center gap-4 mb-16">
          <div className="h-px flex-1 bg-gradient-to-r from-cyan-500/50 to-transparent" />
          <span className="text-sm font-mono text-cyan-400 uppercase tracking-widest">
            About Me
          </span>
          <div className="h-px flex-1 bg-gradient-to-l from-purple-500/50 to-transparent" />
        </div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Content */}
          <div ref={contentRef} className="space-y-6">
            <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk">
              <span className="text-white">Engineering the </span>
              <span className="gradient-text">Future</span>
            </h2>

            <p className="text-lg text-white/70 leading-relaxed">
              I'm Aryan Rakhecha, a passionate engineering student with a deep love for 
              technology and innovation. My journey in the world of engineering started 
              with a curiosity about how things work, which evolved into a career focused 
              on creating impactful digital solutions.
            </p>

            <p className="text-lg text-white/70 leading-relaxed">
              With expertise spanning across software development, system design, and 
              problem-solving, I bring ideas to life through clean code and creative 
              thinking. I believe in the power of technology to transform lives and 
              businesses.
            </p>

            <div className="flex flex-wrap gap-3 pt-4">
              {['Problem Solver', 'Team Player', 'Fast Learner', 'Creative Thinker'].map(
                (trait) => (
                  <span
                    key={trait}
                    className="px-4 py-2 text-sm text-white/80 glass rounded-full hover:bg-white/10 transition-colors cursor-default"
                  >
                    {trait}
                  </span>
                )
              )}
            </div>

            {/* Quick Info */}
            <div className="grid grid-cols-2 gap-4 pt-6">
              <div className="glass rounded-xl p-4">
                <span className="text-sm text-white/50 block mb-1">Location</span>
                <span className="text-white font-medium">India</span>
              </div>
              <div className="glass rounded-xl p-4">
                <span className="text-sm text-white/50 block mb-1">Education</span>
                <span className="text-white font-medium">Engineering Student</span>
              </div>
            </div>
          </div>

          {/* Image/Visual */}
          <div ref={imageRef} className="relative">
            <div className="relative aspect-square max-w-md mx-auto">
              {/* Decorative rings */}
              <div className="absolute inset-0 border-2 border-cyan-500/20 rounded-full animate-rotate-slow" />
              <div className="absolute inset-4 border-2 border-purple-500/20 rounded-full animate-rotate-slow" style={{ animationDirection: 'reverse', animationDuration: '25s' }} />
              <div className="absolute inset-8 border-2 border-pink-500/20 rounded-full animate-rotate-slow" style={{ animationDuration: '30s' }} />
              
              {/* Center content */}
              <div className="absolute inset-16 glass-strong rounded-2xl flex items-center justify-center overflow-hidden">
                <div className="text-center p-6">
                  <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-gradient-to-br from-cyan-400 via-purple-500 to-pink-500 flex items-center justify-center">
                    <span className="text-3xl font-bold text-white">AR</span>
                  </div>
                  <p className="text-white/80 font-medium">Aryan Rakhecha</p>
                  <p className="text-white/50 text-sm">Engineering Student</p>
                </div>
              </div>

              {/* Floating badges */}
              <div className="absolute top-0 right-0 glass px-3 py-1.5 rounded-full text-xs text-cyan-400 animate-float">
                💻 Developer
              </div>
              <div className="absolute bottom-8 left-0 glass px-3 py-1.5 rounded-full text-xs text-purple-400 animate-float animation-delay-200">
                🚀 Innovator
              </div>
              <div className="absolute top-1/2 -right-4 glass px-3 py-1.5 rounded-full text-xs text-pink-400 animate-float animation-delay-400">
                🎨 Designer
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div
          ref={statsRef}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-20"
        >
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="group glass rounded-2xl p-6 text-center hover-lift gradient-border"
            >
              <stat.icon className="w-6 h-6 mx-auto mb-3 text-cyan-400 group-hover:text-purple-400 transition-colors" />
              <div
                className="stat-value text-3xl md:text-4xl font-bold gradient-text mb-1"
                data-value={stat.value.replace(/\D/g, '')}
              >
                {stat.value}
              </div>
              <div className="text-sm text-white/60">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;
